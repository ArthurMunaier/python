from flask_sqlalchemy import SQLAlchemy

from controllers import calculadora_bp

app.register_blueprint(calculadora_bp)

db = SQLAlchemy()

from .operacao import Operacao

__all__ = ["db", "Operacao"]