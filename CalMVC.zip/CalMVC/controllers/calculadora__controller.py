from flask import Blueprint, render_template, request

from models import Operacao

calculadora_bp = Blueprint(
    "calculadora",
    __name__
)


@calculadora_bp.route("/", methods=["GET", "POST"])
def index():

    resultado = None
    etapas = None

    if request.method == "POST":

        num1 = float(request.form["num1"])
        operacao = request.form["operacao"]

        if operacao == "sqrt":

            resultado = num1 ** 0.5
            etapas = f"√{num1} = {resultado}"

            Operacao.salvar(
                num1,
                0,
                operacao,
                etapas,
                resultado
            )

        else:

            num2 = float(request.form["num2"])

            if operacao == "+":
                resultado = num1 + num2

            elif operacao == "-":
                resultado = num1 - num2

            elif operacao == "*":
                resultado = num1 * num2

            elif operacao == "/":
                resultado = num1 / num2

            elif operacao == "**":
                resultado = num1 ** num2

            etapas = f"{num1} {operacao} {num2} = {resultado}"

            Operacao.salvar(
                num1,
                num2,
                operacao,
                etapas,
                resultado
            )

    historico = Operacao.listar_recentes()

    return render_template(
        "calculadora.html",
        resultados=resultado,
        etapas=etapas,
        historico=historico
    )